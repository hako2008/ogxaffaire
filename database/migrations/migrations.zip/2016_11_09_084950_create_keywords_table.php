<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateKeywordsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('Keywords', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->unsigned();
            $table->foreign('user_id')->references('id')->on('users');

        });

        Schema::create('Keyword_translations', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('Keyword_id')->unsigned();
            
            $table->string('locale')->index();
            $table->string('name');
            $table->unique(['Keyword_id','locale','name']);
            $table->foreign('Keyword_id')->references('id')->on('Keywords')->onDelete('cascade');

        });

        Schema::create('article_Keyword', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('Keyword_id')->unsigned();
            $table->integer('article_id')->unsigned();
            

            $table->unique(['Keyword_id','article_id']);
            $table->foreign('Keyword_id')->references('id')->on('Keywords')->onDelete('cascade');
            $table->foreign('article_id')->references('id')->on('articles')->onDelete('cascade');

            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
